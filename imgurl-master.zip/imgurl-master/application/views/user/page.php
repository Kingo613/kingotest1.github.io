<div class="layui-container" style = "margin-top:2em;margin-bottom:4em;">
	<div class="layui-row layui-col-space18">
		<div class="layui-col-lg9">
			<div class = "htmlcontent"><?php echo $content; ?></div>
		</div>
		<div class="layui-col-lg3">
			<div id="page-sidebar">
				<div class = "sidebar">
					<a href="https://e.aiguobit.com/?from=xiaoz" target="_blank" rel="nofollow noopener"><img src = 'https://i.bmp.ovh/imgs/2019/05/e35a8c54260c8410.jpg' /></a>
				</div>
				<div class = "sidebar">
					<a href="https://dwz.ovh/tencent" target="_blank" rel="nofollow">
						<img src = 'https://i.bmp.ovh/imgs/2019/03/f77699ba0787ee47.jpg' />
					</a>
				</div>
				<div class = "sidebar">
					<a href="https://www.xiaoz.me/laoxue" target="_blank" rel="nofollow">
						<img src = 'https://i.bmp.ovh/imgs/2018/12/17d94aafd02d1fbd.png' />
					</a>
				</div>
			</div>
		</div>
	</div>
</div>